NODE_LAMBDA=./node_modules/node-lambda/bin/node-lambda

test -s $NODE_LAMBDA || { echo "node-lambda not installed. Run 'npm install' first."; exit 1; }
mkdir -p tmp
cat .env | grep HOOK_URL > ./tmp/deploy.env
mkdir -p target
$NODE_LAMBDA package --packageDirectory ./target/